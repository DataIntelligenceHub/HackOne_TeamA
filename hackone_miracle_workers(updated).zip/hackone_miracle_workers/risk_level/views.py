from __future__ import division
from django.shortcuts import render
from django.http import HttpResponse
from django.template import Context
from django.shortcuts import render_to_response
from django.template.loader import get_template
from django.template import RequestContext
from django.http import HttpResponseRedirect
from django.core.context_processors import csrf
import json
#import urllib
import urllib.request
# Create your views here.


def index(request):
    args = {}
    args.update(csrf(request))
    return render(request, 'hello.html')

def predict(request):
	if request.method == "POST":
		Product_Info_2 = request.POST.get('Product_Info_2')
		Ins_Age = request.POST.get('Ins_Age')
		BMI = request.POST.get('BMI')
		Employment_Info_2 = request.POST.get('Employment_Info_2')
		Employment_Info_3 = request.POST.get('Employment_Info_3')
		Medical_History_4 = request.POST.get('Medical_History_4')
		Medical_History_15 = request.POST.get('Medical_History_15')
		Medical_History_28 = request.POST.get('Medical_History_28')
		Medical_Keyword_3 = request.POST.get('Medical_Keyword_3')
		Medical_Keyword_15 = request.POST.get('Medical_Keyword_15')
		Response = request.POST.get('Response')
		

		data_list = []

		data_list.append(str(Product_Info_2))
		data_list.append(str(Ins_Age))
		data_list.append(str(BMI))
		data_list.append(str(Employment_Info_2))
		data_list.append(str(Employment_Info_3))
		data_list.append(str(Medical_History_4))
		data_list.append(str(Medical_History_15))
		data_list.append(str(Medical_History_28))
		data_list.append(str(Medical_Keyword_3))
		data_list.append(str(Medical_Keyword_15))
		data_list.append(str(Response))
		
		print(data_list)
		data =  {

        "Inputs": {

                "input1":
                {
                    "ColumnNames": ["Product_Info_2", "Ins_Age", "BMI", "Employment_Info_2", "Employment_Info_3", "Medical_History_4", "Medical_History_15", "Medical_History_28", "Medical_Keyword_3", "Medical_Keyword_15", "Response"],
                    "Values": [ data_list, ]
                },        },
            "GlobalParameters": {
		}
			}

		body = str.encode(json.dumps(data))

		url = 'https://ussouthcentral.services.azureml.net/workspaces/e7b84f1ce6344d3699d23f81c6017abc/services/3789e2f411414d9b986c707a35abcf69/execute?api-version=2.0&details=true'
		api_key = 'smvfybXUSaba7j6WkdDbjx9K5EQjyC96abe5K8mWAI2KWQOZrrRUQA4RfUcUzQGnUwmzdxMeqlxCWtrBIPv2IA==' # Replace this with the API key for the web service
		headers = {'Content-Type':'application/json', 'Authorization':('Bearer '+ api_key)}

		req = urllib.request.Request(url, body, headers)
		print(req)
		try:
			response = urllib.request.urlopen(req)

			# If you are using Python 3+, replace urllib2 with urllib.request in the above code:
			# req = urllib.request.Request(url, body, headers) 
			# response = urllib.request.urlopen(req)

			#result = response.read()
			result = json.loads(response.read())
			print("MESG")
			var1 = result['Results']['output1']['value']['Values'][0][19]
			print("Predicted Score is: "+var1)
			return HttpResponse("Predicted Score is: "+var1)
			print("MSG END")
			#print("type123"+str(type(result['Results']['output1']['value']['Values'][0][19])))
			
		except OSError as error:
			
							
			print("The request failed with status code: " + str(error.code))

			# Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
			print(error.info())

			print(json.loads(error.read()))
			
	return HttpResponse(result)