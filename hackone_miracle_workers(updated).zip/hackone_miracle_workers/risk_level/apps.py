from django.apps import AppConfig


class RiskLevelConfig(AppConfig):
    name = 'risk_level'
